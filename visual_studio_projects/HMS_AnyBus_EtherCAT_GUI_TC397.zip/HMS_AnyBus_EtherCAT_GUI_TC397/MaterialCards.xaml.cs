﻿using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using TwinCAT.Ads;
//using Wpf.Annotations;

namespace Wpf.CartesianChart.MaterialCards
{
    /// <summary>
    /// Interaction logic for MaterialCards.xaml
    /// </summary>
    public partial class MaterialCards : UserControl, INotifyPropertyChanged
    {
        private double _lastLecture1;
        private double _lastLecture2;
        private double _lastLecture3;
        private double _lastLecture4;
       // private string i;

        //private double _trend;

        public MaterialCards()
        {
            InitializeComponent();

            //tVOC
            LastHourSeries1 = new SeriesCollection
                {
                    new LineSeries
                    {
                        AreaLimit = -10,
                        Values = new ChartValues<ObservableValue>
                        {
                            new ObservableValue(50),
                            new ObservableValue(40),
                            new ObservableValue(30),
                            new ObservableValue(20),
                            new ObservableValue(10),
                            new ObservableValue(1),
                            new ObservableValue(10),
                            new ObservableValue(20),
                            new ObservableValue(30),
                            new ObservableValue(40),
                            new ObservableValue(50),
                            new ObservableValue(60),
                            new ObservableValue(70),
                            new ObservableValue(80),
                            new ObservableValue(90),
                            new ObservableValue(100),
                            new ObservableValue(90),
                            new ObservableValue(80)
                        }
                    }
                };
            //_trend = 8;

#if NET40
                Task.Factory.StartNew(() =>
                {
                    var r = new Random();
     
                    Action action = delegate
                    {
                        LastHourSeries1[0].Values.Add(new ObservableValue(_trend));
                       SetLecture1();
                        LastHourSeries1[0].Values.RemoveAt(0);

                    };
     
                    while (true)
                    {
                        Thread.Sleep(500);
                        _trend += (r.NextDouble() > 0.3 ? 1 : -1) * r.Next(0, 5);
                        Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, action);
                    }
                });
#endif
            //#if NET45
            Task.Run(() =>
            {
                //var r = new Random();
                uint hint1 = 0;
                int iHandle = 0;
                int maxima = 100;

                TcAdsClient tcClient = new TwinCAT.Ads.TcAdsClient();
                AdsStream dataStream = new AdsStream(2);
                AdsBinaryReader binReader = new AdsBinaryReader(dataStream);
                tcClient.Connect(851);
                iHandle = tcClient.CreateVariableHandle("GVL.tvoc_ppb");

                while (true)
                {
                    Thread.Sleep(1000);
                    tcClient.Read(iHandle, dataStream);
                    hint1 = binReader.ReadUInt16();
                    dataStream.Position = 0;

                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var r = hint1;
                        if (LastHourSeries1[0].Values.Count > maxima - 1) LastHourSeries1[0].Values.RemoveAt(0);
                        if (LastHourSeries1[0].Values.Count < maxima) LastHourSeries1[0].Values.Add(new ObservableValue(hint1));
                        SetLecture1();
                    });
                }
            });
            //#endif

            DataContext = this;

            //CO2eq
            LastHourSeries2 = new SeriesCollection
            {
                    new LineSeries
                    {
                        AreaLimit = -10,
                        Values = new ChartValues<ObservableValue>
                        {
                            new ObservableValue(400),
                            new ObservableValue(500),
                            new ObservableValue(600),
                            new ObservableValue(700),
                            new ObservableValue(800),
                            new ObservableValue(900),
                            new ObservableValue(1000),
                            new ObservableValue(900),
                            new ObservableValue(800),
                            new ObservableValue(700),
                            new ObservableValue(600),
                            new ObservableValue(500),
                            new ObservableValue(400),
                            new ObservableValue(500),
                            new ObservableValue(600),
                            new ObservableValue(700),
                            new ObservableValue(800),
                            new ObservableValue(900)
                        }
                    }
            };

            //#if NET45
            Task.Run(() =>
            {
                //var r = new Random();
                uint hint1 = 0;
                int iHandle = 0;
                int maxima = 100;

                TcAdsClient tcClient = new TwinCAT.Ads.TcAdsClient();
                AdsStream dataStream = new AdsStream(2);
                AdsBinaryReader binReader = new AdsBinaryReader(dataStream);
                tcClient.Connect(851);
                iHandle = tcClient.CreateVariableHandle("GVL.co2_eq_ppm");

                while (true)
                {
                    Thread.Sleep(1000);
                    //_trend += (r.NextDouble() > 0.3 ? 1 : -1) * r.Next(0, 5);
                    tcClient.Read(iHandle, dataStream);
                    hint1 = binReader.ReadUInt16();
                    dataStream.Position = 0;

                    //77Border2.Background = System.Windows.Media.Brushes.Red;

                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var r = hint1;
                        if (LastHourSeries2[0].Values.Count > maxima - 1) LastHourSeries2[0].Values.RemoveAt(0);
                        if (LastHourSeries2[0].Values.Count < maxima) LastHourSeries2[0].Values.Add(new ObservableValue(hint1));
                        SetLecture2();

                    });
                }
            });
            //#endif

            DataContext = this;

            //Ethanol
            LastHourSeries3 = new SeriesCollection
                {
                    new LineSeries
                    {
                        AreaLimit = -10,
                        Values = new ChartValues<ObservableValue>
                        {
                            new ObservableValue(1000),
                            new ObservableValue(2000),
                            new ObservableValue(3000),
                            new ObservableValue(4000),
                            new ObservableValue(5000),
                            new ObservableValue(6000),
                            new ObservableValue(7000),
                            new ObservableValue(8000),
                            new ObservableValue(9000),
                            new ObservableValue(10000),
                            new ObservableValue(9000),
                            new ObservableValue(8000),
                            new ObservableValue(7000),
                            new ObservableValue(6000),
                            new ObservableValue(5000),
                            new ObservableValue(4000),
                            new ObservableValue(3000),
                            new ObservableValue(2000)
                        }
                    }
                };
            // _trend = 8;

#if NET40
                Task.Factory.StartNew(() =>
                {
                    var r = new Random();
     
                    Action action = delegate
                    {
                        LastHourSeries3[0].Values.Add(new ObservableValue(_trend));
                        LastHourSeries3[0].Values.RemoveAt(0);
                        SetLecture1();
                    };
     
                    while (true)
                    {
                        Thread.Sleep(500);
                        _trend += (r.NextDouble() > 0.3 ? 1 : -1) * r.Next(0, 5);
                        Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, action);
                    }
                });
#endif
            //#if NET45
            Task.Run(() =>
            {
                //var r = new Random();
                uint hint1 = 0;
                int iHandle = 0;
                int maxima = 100;

                TcAdsClient tcClient = new TwinCAT.Ads.TcAdsClient();
                AdsStream dataStream = new AdsStream(2);
                AdsBinaryReader binReader = new AdsBinaryReader(dataStream);
                tcClient.Connect(851);
                iHandle = tcClient.CreateVariableHandle("GVL.scaled_ethanol_signal");

                while (true)
                {
                    Thread.Sleep(1000);
                    //_trend += (r.NextDouble() > 0.3 ? 1 : -1) * r.Next(0, 5);
                    tcClient.Read(iHandle, dataStream);
                    hint1 = binReader.ReadUInt16();
                    dataStream.Position = 0;

                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var r = hint1;
                        if (LastHourSeries3[0].Values.Count > maxima - 1) LastHourSeries3[0].Values.RemoveAt(0);
                        if (LastHourSeries3[0].Values.Count < maxima) LastHourSeries3[0].Values.Add(new ObservableValue(hint1));
                        SetLecture3();
                    });
                }
            });
            //#endif

            DataContext = this;

            //H2 Signal
            LastHourSeries4 = new SeriesCollection
                {
                    new LineSeries
                    {
                        AreaLimit = -10,
                        Values = new ChartValues<ObservableValue>
                        {
                            new ObservableValue(1000),
                            new ObservableValue(2000),
                            new ObservableValue(3000),
                            new ObservableValue(4000),
                            new ObservableValue(5000),
                            new ObservableValue(6000),
                            new ObservableValue(7000),
                            new ObservableValue(8000),
                            new ObservableValue(9000),
                            new ObservableValue(10000),
                            new ObservableValue(9000),
                            new ObservableValue(8000),
                            new ObservableValue(7000),
                            new ObservableValue(6000),
                            new ObservableValue(5000),
                            new ObservableValue(4000),
                            new ObservableValue(3000),
                            new ObservableValue(2000)
                        }
                    }
                };
            //_trend = 8;

#if NET40
                Task.Factory.StartNew(() =>
                {
                    var r = new Random();
     
                    Action action = delegate
                    {
                        LastHourSeries4[0].Values.Add(new ObservableValue(_trend));
                        LastHourSeries4[0].Values.RemoveAt(0);
                        SetLecture1();
                    };
     
                    while (true)
                    {
                        Thread.Sleep(500);
                        _trend += (r.NextDouble() > 0.3 ? 1 : -1) * r.Next(0, 5);
                        Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, action);
                    }
                });
#endif
            //#if NET45
            Task.Run(() =>
            {
                //var r = new Random();
                uint hint1 = 0;
                int iHandle = 0;
                const int maxima = 100;


                TcAdsClient tcClient = new TwinCAT.Ads.TcAdsClient();
                AdsStream dataStream = new AdsStream(2);
                AdsBinaryReader binReader = new AdsBinaryReader(dataStream);
                tcClient.Connect(851);
                iHandle = tcClient.CreateVariableHandle("GVL.scaled_h2_signal");
                while (true)
                {
                    Thread.Sleep(1000);
                    //_trend += (r.NextDouble() > 0.3 ? 1 : -1) * r.Next(0, 5);
                    tcClient.Read(iHandle, dataStream);
                    hint1 = binReader.ReadUInt16();
                    dataStream.Position = 0;

                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var r = hint1;
                        if (LastHourSeries4[0].Values.Count > maxima - 1) LastHourSeries4[0].Values.RemoveAt(0);
                        if (LastHourSeries4[0].Values.Count < maxima) LastHourSeries4[0].Values.Add(new ObservableValue(hint1));
                        SetLecture4();
                    });
                }
            });
            //#endif

            DataContext = this;
        }

        public SeriesCollection LastHourSeries1 { get; set; }
        public double LastLecture1
        {
            get { return _lastLecture1; }
            set
            {
                _lastLecture1 = value;
                OnPropertyChanged("LastLecture1");
            }
        }

        public SeriesCollection LastHourSeries2 { get; set; }
        public double LastLecture2
        {
            get { return _lastLecture2; }
            set
            {
                _lastLecture2 = value;
                OnPropertyChanged("LastLecture2");
            }
        }
        public SeriesCollection LastHourSeries3 { get; set; }
        public double LastLecture3
        {
            get { return _lastLecture3; }
            set
            {
                _lastLecture3 = value;
                OnPropertyChanged("LastLecture3");
            }
        }
        public SeriesCollection LastHourSeries4 { get; set; }
        public double LastLecture4
        {
            get { return _lastLecture4; }
            set
            {
                _lastLecture4 = value;
                OnPropertyChanged("LastLecture4");
            }
        }

        private void SetLecture1()
        {
            var target = ((ChartValues<ObservableValue>)LastHourSeries1[0].Values).Last().Value;
            //var target1 = LastHourSeries1[0];
            //var step = (target1 - _lastlecture1) / 4;

#if net40
                        task.factory.startnew(() =>
                        {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            lastlecture1 = target1;
                        });
#endif
            //#if net45
            Task.Run(() =>
            {

                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture1 += step;
                            //}
                            //lastlecture = lasthourseries1[0];
                            Thread.Sleep(1000);
                LastLecture1 = target;
            });
            //#endif
        }

        private void SetLecture2()
        {
            var target = ((ChartValues<ObservableValue>)LastHourSeries2[0].Values).Last().Value;
            //var step = (target - _lastlecture1) / 4;

            /*
             * 
             * AGO Modification 27.03.2020
             * Co² measures limits in parts per million [ppm]
             * 400 test
             * 
             * source: https://wissenwiki.de/Kohlenstoffdioxid
             * 
             * 
             * */
            if (target >= 2000) // Danker for Air quality
            {
                Co2eq.Background = System.Windows.Media.Brushes.Red;
                Co2eq.Foreground = System.Windows.Media.Brushes.White;
                Border_diagramC02.Background = System.Windows.Media.Brushes.Red;
                Co2eqConcentration.Background = System.Windows.Media.Brushes.Red;
                Co2eqConcentration.Foreground = System.Windows.Media.Brushes.White;
                //Border2.Background = System.Windows.Media.Brushes.Red;
                CO2_Value.Foreground = System.Windows.Media.Brushes.Red;
                ppm.Foreground = System.Windows.Media.Brushes.Red;
                //textCarboneDioxide.Foreground = System.Windows.Media.Brushes.White;


            }
            else if (target >= 1000) // Warning for Air quality
            {

              
                Co2eq.Background = System.Windows.Media.Brushes.Orange;
                Co2eq.Foreground = System.Windows.Media.Brushes.White;
                Border_diagramC02.Background = System.Windows.Media.Brushes.Orange;
                Co2eqConcentration.Background = System.Windows.Media.Brushes.Orange;
                Co2eqConcentration.Foreground = System.Windows.Media.Brushes.White;
                //Border2.Background = System.Windows.Media.Brushes.Orange;
                CO2_Value.Foreground = System.Windows.Media.Brushes.Orange;
                ppm.Foreground = System.Windows.Media.Brushes.Orange;
                //textCarboneDioxide.Foreground = System.Windows.Media.Brushes.White;

            }
            else // Normal Air Quality 
            {
                Co2eq.Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x00,0x8b,0xd2));
                Co2eq.Foreground = System.Windows.Media.Brushes.White;

                Border_diagramC02.Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x00, 0x8b, 0xd2));
                Co2eqConcentration.Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x00, 0x8b, 0xd2));
                Co2eqConcentration.Foreground = System.Windows.Media.Brushes.White;
                Border2.Background = System.Windows.Media.Brushes.White;
                textTest.Foreground = System.Windows.Media.Brushes.White;
                textCarboneDioxide.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x66, 0x66, 0x66));
                CO2_Value.Foreground = System.Windows.Media.Brushes.Black;
                ppm.Foreground = System.Windows.Media.Brushes.Black;
            }


#if net40
                        task.factory.startnew(() =>
                        {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            lastlecture2 = target;
                        });
#endif
            //#if net45
            Task.Run(() =>
            {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            Thread.Sleep(1000);
                LastLecture2 = target;
            });
            //#endif
        }

        private void SetLecture3()
        {
            var target = ((ChartValues<ObservableValue>)LastHourSeries3[0].Values).Last().Value;
            //var step = (target - _lastlecture1) / 4;

#if net40
                        task.factory.startnew(() =>
                        {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            lastlecture3 = target;
                        });
#endif
            //#if net45
            Task.Run(() =>
            {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            Thread.Sleep(1000);
                LastLecture3 = target;
            });
            //#endif
        }

        private void SetLecture4()
        {
            var target = ((ChartValues<ObservableValue>)LastHourSeries4[0].Values).Last().Value;
            //var step = (target - _lastlecture1) / 4;

#if net40
                        task.factory.startnew(() =>
                        {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            lastlecture4 = target;
                        });
#endif
            //#if net45
            Task.Run(() =>
            {
                            //for (var i = 0; i < 4; i++)
                            //{
                            //    thread.sleep(100);
                            //    lastlecture += step;
                            //}
                            Thread.Sleep(1000);
                LastLecture4 = target;
            });
            //#endif
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }

        //public event PropertyChangedEventHandler PropertyChanged;

        //protected virtual void OnPropertyChanged(string propertyName = null)
        //{
        //    var handler = PropertyChanged;
        //    if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        //}

        //private void UpdateOnclick(object sender, RoutedEventArgs e)
        //{
        //    TimePowerChart.Update(true);
        //}
    }
}